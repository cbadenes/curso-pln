# Docker compose para instalar entorno jupyter con tensorflow con GPU
Para crear el contendor:

```bash
docker-compose up
```
